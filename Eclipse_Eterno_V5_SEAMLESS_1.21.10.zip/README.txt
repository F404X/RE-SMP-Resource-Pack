ECLIPSE ETERNO V5 — TEXTURA CORRIGIDA

Minecraft Java 1.21.10 / Fabric / Skyboxify

CORREÇÃO PRINCIPAL
------------------
A versão anterior criava cada face do skybox separadamente. Isso podia
produzir uma grande área retangular/diagonal visível no céu, especialmente
perto do Sol.

Nesta versão, o céu é primeiro construído como UMA esfera contínua e depois
convertido para as seis faces do cubemap. Não há mais uma "placa" independente
de céu atrás do eclipse.

O céu também não possui nuvens/blocos grandes no alto, justamente para evitar
qualquer mancha ou emenda visual.

SOL
---
O Sol continua somente em:
assets/minecraft/textures/environment/sun.png

Ele é um disco negro com uma corona clara de eclipse total e acompanha a
trajetória normal do Sol vanilla.

MOVIMENTO
---------
sky1.properties usa:
rotate=true
speed=1.0

Isso faz o skybox acompanhar o ciclo diário do mundo.

Se o ciclo do mundo for congelado com:
    /gamerule doDaylightCycle false

o Sol e o movimento do céu ficam parados porque o horário do mundo deixa de
avançar. Ao usar:
    /gamerule doDaylightCycle true

eles voltam a se mover.

INSTALAÇÃO
----------
Coloque o ZIP na pasta resourcepacks e ative-o.
Requer Fabric + Fabric API + Skyboxify compatível com 1.21.10.
